import React from "react";

const FormSuccess = () => {
  return (
    <div className="form-content-application">
      <div className="form-success-application">
        We have received your Scholarship request.
      </div>
    </div>
  );
};

export default FormSuccess;
