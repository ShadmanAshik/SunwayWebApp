import React from "react";

const AdmissionFormSuccess = () => {
  return (
    <div className="form-content-application">
      <div className="form-success-application">
        We have received your Scholarship request.
      </div>
    </div>
  );
};

export default AdmissionFormSuccess;
